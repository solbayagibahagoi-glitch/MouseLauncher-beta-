package com.mouse.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(245, 243, 250)
    private val ink = Color.rgb(35, 35, 45)
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private var drawerOpen = false
    private var apps: List<ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadApps()
        showHome()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(ink)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun showHome() {
        drawerOpen = false
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(14))
            background = rounded(bg, dp(0).toFloat())
        }

        val date = label("Mouse Launcher", 25f, true).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }
        root.addView(date, LinearLayout.LayoutParams(-1, dp(54)))

        val subtitle = label("Your phone, your space", 14f).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(Color.rgb(105, 102, 117))
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(30)))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val search = TextView(this).apply {
            text = "⌕    Search apps"
            textSize = 16f
            setTextColor(Color.rgb(70, 68, 80))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = rounded(Color.rgb(230, 227, 238), dp(30).toFloat())
            setOnClickListener { showDrawer() }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(56)))

        val quickRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(18), 0, dp(10))
        }
        val featured = apps.take(4)
        if (featured.isNotEmpty()) {
            featured.forEach { info ->
                quickRow.addView(createAppTile(info, compact = true), LinearLayout.LayoutParams(0, dp(92), 1f))
            }
        } else {
            quickRow.addView(label("No apps found", 14f))
        }
        root.addView(quickRow, LinearLayout.LayoutParams(-1, dp(100)))

        val allApps = TextView(this).apply {
            text = "All apps  ↑"
            textSize = 14f
            setTextColor(ink)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(230, 227, 238), dp(24).toFloat())
            setOnClickListener { showDrawer() }
        }
        root.addView(allApps, LinearLayout.LayoutParams(-1, dp(48)))
        setContentView(root)
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(220).start()
    }

    private fun showDrawer() {
        drawerOpen = true
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(12))
            background = rounded(Color.rgb(249, 247, 253), dp(28).toFloat())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = label("All apps", 24f, true).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        header.addView(title, LinearLayout.LayoutParams(0, dp(54), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(ink)
            setOnClickListener { showHome() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(48)))
        panel.addView(header)

        val scroll = ScrollView(this)
        appGrid = GridLayout(this).apply {
            columnCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        apps.forEach { info ->
            val tile = createAppTile(info, compact = false)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(100)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(4), dp(2), dp(4))
            }
            appGrid.addView(tile, params)
        }
        scroll.addView(appGrid)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(panel)
        panel.scaleX = 0.94f
        panel.scaleY = 0.94f
        panel.alpha = 0f
        panel.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun createAppTile(info: ResolveInfo, compact: Boolean): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(5), dp(3), dp(4))
            isClickable = true
            isFocusable = true
        }

        val iconHolder = FrameLayout(this).apply {
            background = rounded(Color.rgb(232, 229, 241), dp(23).toFloat())
            clipToOutline = true
        }
        val icon = ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        iconHolder.addView(icon, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
        tile.addView(iconHolder, LinearLayout.LayoutParams(dp(56), dp(56)))

        val name = label(info.loadLabel(packageManager).toString(), 11f).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(5), 0, 0)
        }
        tile.addView(name, LinearLayout.LayoutParams(-1, dp(25)))

        tile.setOnClickListener {
            tile.animate().scaleX(0.88f).scaleY(0.88f).alpha(0.75f).setDuration(90)
                .withEndAction {
                    tile.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(130).start()
                    try {
                        val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                        } else {
                            Toast.makeText(this, "Cannot open this app", Toast.LENGTH_SHORT).show()
                        }
                    } catch (_: Exception) {
                        Toast.makeText(this, "Could not open app", Toast.LENGTH_SHORT).show()
                    }
                }.start()
        }

        tile.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setTitle(info.loadLabel(packageManager))
                .setMessage(info.activityInfo.packageName)
                .setPositiveButton("OK", null)
                .show()
            true
        }
        return tile
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (drawerOpen) showHome() else super.onBackPressed()
    }
}
